class SSOException(Exception):
    pass
